<?php if ( is_active_sidebar( 'above-footer-widgets-area' ) ) : ?>
	<div class="above-footer-widgets-area section-splitter">
		<div class="section-wrapper">
			<?php dynamic_sidebar( 'above-footer-widgets-area' ); ?>
		</div>
	</div>
<?php endif; ?>
