<?php

// Banner Section.
require get_template_directory() . '/sections/banner.php';

// Main Widgets Section.
require get_template_directory() . '/sections/main-widgets-section.php';

// Above Footer Widgets Section.
require get_template_directory() . '/sections/above-footer-widgets.php';
